import { useState, useEffect, useRef } from "react";

// ─── Animated Counter ────────────────────────────────────────────────────────
function useCountUp(end: number, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [end, duration, start]);
  return count;
}

// ─── Intersection Observer Hook ───────────────────────────────────────────────
function useInView(threshold = 0.2) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return { ref, inView };
}

// ─── Nav ─────────────────────────────────────────────────────────────────────
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-slate-950/95 backdrop-blur-md border-b border-amber-500/20 shadow-lg shadow-black/40"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-18 py-4">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-md shadow-amber-500/30">
            <svg className="w-5 h-5 text-slate-950" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
            </svg>
          </div>
          <span className="font-cinzel text-lg font-bold text-white tracking-wide leading-none">
            Politics<span className="text-amber-400">&</span>War
          </span>
        </div>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          {["Features", "Alliances", "Wars", "Trade", "History"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="text-slate-300 hover:text-amber-400 text-sm font-medium transition-colors duration-200 tracking-wide"
            >
              {item}
            </a>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href="https://politicsandwar.com/login/"
            className="text-sm font-medium text-slate-300 hover:text-white transition-colors px-4 py-2 rounded-lg border border-slate-700 hover:border-slate-500"
          >
            Login
          </a>
          <a
            href="https://politicsandwar.com/register/"
            className="text-sm font-semibold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 px-5 py-2 rounded-lg transition-all duration-200 shadow-md shadow-amber-500/20 hover:shadow-amber-500/40"
          >
            Play Free
          </a>
        </div>

        {/* Hamburger */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="md:hidden text-slate-300 hover:text-white"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
            {menuOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-slate-950/98 border-t border-slate-800 px-6 py-4 flex flex-col gap-3">
          {["Features", "Alliances", "Wars", "Trade", "History"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              onClick={() => setMenuOpen(false)}
              className="text-slate-300 hover:text-amber-400 text-sm font-medium py-2 border-b border-slate-800"
            >
              {item}
            </a>
          ))}
          <div className="flex gap-3 pt-2">
            <a href="https://politicsandwar.com/login/" className="flex-1 text-center text-sm font-medium text-slate-300 border border-slate-700 py-2 rounded-lg">Login</a>
            <a href="https://politicsandwar.com/register/" className="flex-1 text-center text-sm font-semibold bg-amber-500 text-slate-950 py-2 rounded-lg">Play Free</a>
          </div>
        </div>
      )}
    </nav>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────────
function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url('/images/hero-bg.jpg')" }}
      />
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-950/70 via-slate-950/50 to-slate-950" />
      {/* Radial glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(245,158,11,0.08)_0%,_transparent_70%)]" />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold uppercase tracking-widest px-4 py-2 rounded-full mb-8">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          Free to Play · 10+ Years of History
        </div>

        <h1 className="font-cinzel text-5xl sm:text-6xl md:text-7xl font-black text-white leading-tight mb-6 drop-shadow-2xl">
          The Ultimate<br />
          <span className="bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 bg-clip-text text-transparent">
            Political Strategy
          </span>
          <br />Game
        </h1>

        <p className="text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed mb-10">
          Build your own nation, forge powerful alliances, command armies, and
          shape the global political landscape—with thousands of real players
          around the world.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="https://politicsandwar.com/register/"
            className="group flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-lg px-8 py-4 rounded-xl transition-all duration-300 shadow-xl shadow-amber-500/25 hover:shadow-amber-500/50 hover:scale-105"
          >
            Start Playing Free
            <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </a>
          <a
            href="https://politicsandwar.com/login/"
            className="flex items-center gap-2 border-2 border-slate-600 hover:border-amber-400/60 text-slate-300 hover:text-white font-semibold text-lg px-8 py-4 rounded-xl transition-all duration-300 hover:bg-white/5"
          >
            Login
          </a>
        </div>

        {/* Stats row */}
        <div className="mt-16 grid grid-cols-3 gap-6 max-w-lg mx-auto">
          {[
            { value: "756K+", label: "Nations Created" },
            { value: "15K+", label: "Active Nations" },
            { value: "10+", label: "Years Running" },
          ].map(({ value, label }) => (
            <div key={label} className="text-center">
              <div className="text-2xl sm:text-3xl font-cinzel font-bold text-amber-400">{value}</div>
              <div className="text-xs text-slate-400 mt-1 uppercase tracking-wider">{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-500 text-xs animate-bounce">
        <span className="tracking-widest uppercase text-xs">Scroll</span>
        <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
        </svg>
      </div>
    </section>
  );
}

// ─── Feature Card ─────────────────────────────────────────────────────────────
function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="group relative bg-slate-900/60 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-6 transition-all duration-300 hover:bg-slate-900/80 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-500/5">
      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 border border-amber-500/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
        {icon}
      </div>
      <h3 className="text-white font-semibold text-lg mb-2 font-cinzel">{title}</h3>
      <p className="text-slate-400 text-sm leading-relaxed">{description}</p>
    </div>
  );
}

// ─── Features Overview ────────────────────────────────────────────────────────
function Features() {
  return (
    <section id="features" className="bg-slate-950 py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest">Everything You Need</span>
          <h2 className="font-cinzel text-4xl sm:text-5xl font-bold text-white mt-3 mb-4">
            Create Your Country,<br />Your Way
          </h2>
          <p className="text-slate-400 max-w-xl mx-auto leading-relaxed">
            From naming your leader to deploying nuclear weapons—every decision is yours to make in a completely player-driven world.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <FeatureCard
            icon={<svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.4 7h12.8M7 13h10" /></svg>}
            title="Nation Customization"
            description="Name your leader, design your flag, choose your currency, national animal, and set policies for peace or war."
          />
          <FeatureCard
            icon={<svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>}
            title="Alliance Diplomacy"
            description="Join or form alliances with rich traditions, Discord servers, forums, and over 10 years of community history."
          />
          <FeatureCard
            icon={<svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>}
            title="Massive Wars"
            description="Global conflicts with thousands of real players. Raid enemies, place bounties, and unleash nuclear weapons."
          />
          <FeatureCard
            icon={<svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
            title="Player-Driven Economy"
            description="Produce, refine, and trade resources in a completely free-market system. No bots—only real player interaction."
          />
          <FeatureCard
            icon={<svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" /></svg>}
            title="World Map"
            description="Claim territory, expand borders, and compete geographically across a persistent, ever-evolving world map."
          />
          <FeatureCard
            icon={<svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>}
            title="Mobile App"
            description="Available on iOS and Android so you can manage your nation and make strategic decisions anywhere, anytime."
          />
        </div>
      </div>
    </section>
  );
}

// ─── Section Block (alternating image/text) ───────────────────────────────────
function SectionBlock({
  id,
  tag,
  title,
  description,
  imageSrc,
  imageAlt,
  reverse = false,
  bullets = [],
}: {
  id: string;
  tag: string;
  title: string;
  description: string;
  imageSrc: string;
  imageAlt: string;
  reverse?: boolean;
  bullets?: string[];
}) {
  const { ref, inView } = useInView();

  return (
    <section id={id} className="relative bg-slate-950 py-24 px-6 overflow-hidden">
      {/* Subtle section divider glow */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-500/30 to-transparent" />

      <div ref={ref} className={`max-w-7xl mx-auto flex flex-col ${reverse ? "lg:flex-row-reverse" : "lg:flex-row"} items-center gap-16`}>
        {/* Image */}
        <div
          className={`flex-1 transition-all duration-1000 ${inView ? "opacity-100 translate-x-0" : reverse ? "opacity-0 translate-x-12" : "opacity-0 -translate-x-12"}`}
        >
          <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-black/60 border border-slate-800">
            <img src={imageSrc} alt={imageAlt} className="w-full h-80 object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 to-transparent" />
          </div>
        </div>

        {/* Text */}
        <div
          className={`flex-1 transition-all duration-1000 delay-200 ${inView ? "opacity-100 translate-x-0" : reverse ? "opacity-0 -translate-x-12" : "opacity-0 translate-x-12"}`}
        >
          <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest">{tag}</span>
          <h2 className="font-cinzel text-3xl sm:text-4xl font-bold text-white mt-3 mb-5 leading-tight">{title}</h2>
          <p className="text-slate-400 leading-relaxed mb-6">{description}</p>
          {bullets.length > 0 && (
            <ul className="space-y-3">
              {bullets.map((b) => (
                <li key={b} className="flex items-start gap-3 text-slate-300 text-sm">
                  <span className="mt-1 flex-shrink-0 w-5 h-5 rounded-full bg-amber-500/15 border border-amber-500/30 flex items-center justify-center">
                    <svg className="w-3 h-3 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  {b}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
  );
}

// ─── Stats Band ───────────────────────────────────────────────────────────────
function StatsBand() {
  const { ref, inView } = useInView(0.3);
  const nations = useCountUp(756536, 2500, inView);
  const active = useCountUp(15398, 2000, inView);
  const online = useCountUp(666, 1500, inView);
  const weeks = useCountUp(1308, 2000, inView);

  return (
    <section className="relative bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 py-16 px-6 overflow-hidden">
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")" }} />
      <div ref={ref} className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center relative z-10">
        {[
          { value: nations.toLocaleString(), suffix: "+", label: "Nations Simulated" },
          { value: active.toLocaleString(), suffix: "", label: "Nations Exist Today" },
          { value: online.toLocaleString(), suffix: "", label: "Players Online (Last Hour)" },
          { value: weeks.toLocaleString(), suffix: "+", label: "New Nations This Week" },
        ].map(({ value, suffix, label }) => (
          <div key={label} className="flex flex-col items-center">
            <span className="font-cinzel text-4xl sm:text-5xl font-black text-slate-950">
              {value}{suffix}
            </span>
            <span className="text-slate-800 text-sm font-medium mt-2 leading-tight">{label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

// ─── Resources Table ──────────────────────────────────────────────────────────
const RESOURCES = [
  { name: "Food", emoji: "🥩", color: "text-green-400" },
  { name: "Coal", emoji: "⬛", color: "text-slate-400" },
  { name: "Oil", emoji: "🛢️", color: "text-slate-400" },
  { name: "Uranium", emoji: "☢️", color: "text-green-400" },
  { name: "Lead", emoji: "🔩", color: "text-slate-400" },
  { name: "Iron", emoji: "⚙️", color: "text-slate-400" },
  { name: "Bauxite", emoji: "🪨", color: "text-orange-400" },
  { name: "Gasoline", emoji: "⛽", color: "text-yellow-400" },
  { name: "Munitions", emoji: "💣", color: "text-red-400" },
  { name: "Steel", emoji: "🏗️", color: "text-slate-300" },
  { name: "Aluminum", emoji: "🔧", color: "text-blue-400" },
  { name: "Credits", emoji: "💳", color: "text-amber-400" },
];

function ResourcesSection() {
  return (
    <section id="trade" className="relative bg-slate-950 py-24 px-6 overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-500/30 to-transparent" />
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-16 items-start">
          {/* Left: Text */}
          <div className="flex-1">
            <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest">Economy</span>
            <h2 className="font-cinzel text-3xl sm:text-4xl font-bold text-white mt-3 mb-5 leading-tight">
              100% Player-Driven<br />Free Market Economics
            </h2>
            <p className="text-slate-400 leading-relaxed mb-6">
              Experience a completely laissez-faire economy where the market is driven entirely by players' actions. 
              Produce, refine, and trade resources to meet your nation's needs in a true free-market system.
            </p>
            <p className="text-slate-400 leading-relaxed mb-6">
              Raw resources are geographically limited, encouraging players to specialize and trade with others. 
              Set up complex trade structures, manage embargoes, and create preferred markets to gain an economic edge.
            </p>
            <img src="/images/trade.jpg" alt="Global Trade" className="rounded-2xl w-full h-56 object-cover border border-slate-800 shadow-xl shadow-black/40" />
          </div>

          {/* Right: Resources grid */}
          <div className="flex-1">
            <h3 className="text-white font-semibold text-lg mb-4 font-cinzel">Tradeable Resources</h3>
            <div className="grid grid-cols-2 gap-3">
              {RESOURCES.map(({ name, emoji, color }) => (
                <div
                  key={name}
                  className="flex items-center gap-3 bg-slate-900/60 border border-slate-800 hover:border-amber-500/30 rounded-xl px-4 py-3 transition-all duration-200 hover:bg-slate-900 cursor-default"
                >
                  <span className="text-2xl">{emoji}</span>
                  <div>
                    <div className={`text-sm font-semibold ${color}`}>{name}</div>
                    <div className="text-xs text-slate-500">Market tradeable</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── Testimonial / Community ──────────────────────────────────────────────────
function CommunitySection() {
  return (
    <section className="relative bg-slate-900/50 py-24 px-6 overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-500/30 to-transparent" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(245,158,11,0.05)_0%,_transparent_60%)]" />

      <div className="max-w-5xl mx-auto relative z-10">
        <div className="text-center mb-14">
          <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest">Community</span>
          <h2 className="font-cinzel text-3xl sm:text-4xl font-bold text-white mt-3 mb-4">
            Join a Living,<br />Breathing World
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Over 10 years of treaties, wars, alliances, and memorable events documented across thousands of wiki pages. 
            Every decision you make becomes part of a larger, ongoing story.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: "🌐",
              title: "Discord Communities",
              desc: "Every major alliance has dedicated Discord servers with thousands of active members strategizing 24/7.",
            },
            {
              icon: "📜",
              title: "Living History",
              desc: "Thousands of wiki pages chronicle the game's wars, treaties, and legendary alliances going back over a decade.",
            },
            {
              icon: "🤝",
              title: "No Bots, Real Players",
              desc: "Every nation, ally, and enemy is a real person. The politics, drama, and friendships are completely authentic.",
            },
          ].map(({ icon, title, desc }) => (
            <div
              key={title}
              className="bg-slate-900/70 border border-slate-800 rounded-2xl p-6 hover:border-amber-500/30 transition-all duration-300 hover:-translate-y-1"
            >
              <div className="text-4xl mb-4">{icon}</div>
              <h3 className="text-white font-semibold text-lg mb-2 font-cinzel">{title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── Founder Story ────────────────────────────────────────────────────────────
function FounderSection() {
  return (
    <section className="relative bg-slate-950 py-24 px-6 overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-500/30 to-transparent" />
      <div className="max-w-4xl mx-auto text-center">
        <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest">Our Story</span>
        <h2 className="font-cinzel text-3xl sm:text-4xl font-bold text-white mt-3 mb-8">From a Dream to a Legacy</h2>

        <div className="relative bg-slate-900/60 border border-slate-800 rounded-3xl p-8 sm:p-12">
          {/* Quote marks */}
          <div className="absolute top-6 left-8 text-8xl text-amber-500/10 font-serif leading-none select-none">"</div>
          <div className="absolute bottom-2 right-8 text-8xl text-amber-500/10 font-serif leading-none select-none">"</div>

          <p className="relative z-10 text-slate-300 text-lg leading-relaxed mb-8">
            Politics and War was started in <strong className="text-amber-400">2013 by Alex Winchell</strong>—a high school student from Montana who dreamed of making his own game. 
            Inspired by Civilization, Age of Empires, NationStates, and Cyber Nations, Alex taught himself development through Google and dozens of failures. 
            He launched Politics and War in <strong className="text-amber-400">August of 2014</strong>, and has continued growing it ever since—now with the help of an incredible community of dedicated players.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 border-t border-slate-800">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-bold text-lg">A</div>
            <div className="text-left">
              <div className="text-white font-semibold">Alex Winchell</div>
              <div className="text-slate-500 text-sm">Founder & Developer, Politics and War</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── App Download ─────────────────────────────────────────────────────────────
function AppDownload() {
  return (
    <section className="relative bg-slate-900/50 py-20 px-6 overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-500/30 to-transparent" />
      <div className="max-w-4xl mx-auto text-center">
        <span className="text-amber-400 text-sm font-semibold uppercase tracking-widest">Mobile</span>
        <h2 className="font-cinzel text-3xl sm:text-4xl font-bold text-white mt-3 mb-4">
          Play Anywhere, Anytime
        </h2>
        <p className="text-slate-400 max-w-xl mx-auto leading-relaxed mb-10">
          Download the Politics and War mobile app to manage your nation on the go—available for free on iOS and Android.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="https://apps.apple.com/us/app/politics-and-war/id1552461332"
            className="flex items-center gap-3 bg-slate-900 border border-slate-700 hover:border-amber-500/40 text-white px-6 py-4 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-black/40 min-w-[180px]"
          >
            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
            </svg>
            <div className="text-left">
              <div className="text-xs text-slate-400">Download on the</div>
              <div className="font-semibold text-sm">App Store</div>
            </div>
          </a>
          <a
            href="https://play.google.com/store/apps/details?id=com.game.politicsandwar"
            className="flex items-center gap-3 bg-slate-900 border border-slate-700 hover:border-amber-500/40 text-white px-6 py-4 rounded-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:shadow-black/40 min-w-[180px]"
          >
            <svg className="w-8 h-8" viewBox="0 0 24 24" fill="currentColor">
              <path d="M3.18 23.76a2 2 0 01-.93-.94V1.18A2 2 0 012.25.24L13.5 12 2.25 23.76a2 2 0 01-.93-.94zm10.32.24L5.16 21.6l2.25-2.25L18 12 7.41 4.65 5.16 2.4 13.5 0l8.25 4.5a2.09 2.09 0 011.25 1.875v11.25a2.09 2.09 0 01-1.25 1.875zm-9.9-2.82l8.22-5.43-2.28-2.28z" fill="#4CAF50"/>
            </svg>
            <div className="text-left">
              <div className="text-xs text-slate-400">Get it on</div>
              <div className="font-semibold text-sm">Google Play</div>
            </div>
          </a>
        </div>
      </div>
    </section>
  );
}

// ─── CTA Banner ───────────────────────────────────────────────────────────────
function CTABanner() {
  return (
    <section className="relative bg-slate-950 py-24 px-6 overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-500/30 to-transparent" />
      {/* Decorative */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(245,158,11,0.08)_0%,_transparent_65%)]" />
      <div className="absolute inset-0 opacity-5" style={{ backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 50px, rgba(245,158,11,0.5) 50px, rgba(245,158,11,0.5) 51px), repeating-linear-gradient(90deg, transparent, transparent 50px, rgba(245,158,11,0.5) 50px, rgba(245,158,11,0.5) 51px)" }} />

      <div className="relative z-10 max-w-3xl mx-auto text-center">
        <h2 className="font-cinzel text-4xl sm:text-5xl font-black text-white leading-tight mb-6">
          Ready to Lead<br />
          <span className="bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent">
            Your Nation?
          </span>
        </h2>
        <p className="text-slate-400 text-lg leading-relaxed mb-10">
          Join thousands of players in Politics and War—the ultimate free online strategy game. 
          Create your country, forge alliances, wage epic wars, and become a global leader.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="https://politicsandwar.com/register/"
            className="group flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-lg px-10 py-4 rounded-xl transition-all duration-300 shadow-2xl shadow-amber-500/25 hover:shadow-amber-500/50 hover:scale-105"
          >
            Create Your Nation — It's Free
            <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </a>
        </div>
        <p className="text-slate-600 text-sm mt-6">No credit card required · 100% Free to Play</p>
      </div>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 py-12 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
                <svg className="w-5 h-5 text-slate-950" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                </svg>
              </div>
              <span className="font-cinzel text-lg font-bold text-white">
                Politics<span className="text-amber-400">&</span>War
              </span>
            </div>
            <p className="text-slate-500 text-sm leading-relaxed max-w-sm">
              The ultimate free browser strategy game where you create and manage your own nation. 
              100% free to play since 2014.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <a href="https://discord.gg/pw" className="w-9 h-9 rounded-lg bg-slate-800 hover:bg-indigo-600 flex items-center justify-center transition-colors duration-200">
                <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.1 18.08.114 18.1.136 18.116a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-4">Game</h4>
            <ul className="space-y-3">
              {["Register", "Login", "Rankings", "Alliance List", "World Map"].map((item) => (
                <li key={item}>
                  <a href={`https://politicsandwar.com/${item.toLowerCase().replace(" ", "-")}/`} className="text-slate-500 hover:text-amber-400 text-sm transition-colors duration-200">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold text-sm uppercase tracking-wider mb-4">Resources</h4>
            <ul className="space-y-3">
              {[
                { label: "Wiki", href: "https://politicsandwar.fandom.com/wiki/Politics_and_War_Wiki" },
                { label: "Discord", href: "https://discord.gg/pw" },
                { label: "Forums", href: "https://politicsandwar.com/forums/" },
                { label: "API", href: "https://politicsandwar.com/api/" },
                { label: "Contact", href: "mailto:support@politicsandwar.com" },
              ].map(({ label, href }) => (
                <li key={label}>
                  <a href={href} className="text-slate-500 hover:text-amber-400 text-sm transition-colors duration-200">
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-slate-600 text-xs">
            © {new Date().getFullYear()} Politics and War. All rights reserved.
          </p>
          <p className="text-slate-600 text-xs">
            Created by Alex Winchell · Launched August 5, 2014
          </p>
        </div>
      </div>
    </footer>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <div className="bg-slate-950 min-h-screen font-inter">
      <Navbar />
      <Hero />
      <Features />

      <SectionBlock
        id="alliances"
        tag="Diplomacy"
        title="Join & Form Powerful Alliances"
        description="In Politics and War, joining an alliance means becoming part of a vibrant online community that goes beyond just playing the game. Alliances have rich histories and strong traditions—like families, complete with forums, Discord servers, and a deep sense of camaraderie. Collaborate to strategize, trade, and defend each other across over 10 years of community history."
        imageSrc="/images/diplomacy.jpg"
        imageAlt="Alliance Diplomacy"
        bullets={[
          "Join forces with players worldwide in structured alliances",
          "Access exclusive alliance forums and Discord communities",
          "Forge treaties and diplomatic agreements",
          "10+ years of documented alliance history and politics",
        ]}
      />

      <SectionBlock
        id="wars"
        tag="Warfare"
        title="Massive Global Battles With Thousands of Players"
        description="Politics and War features epic war gameplay that puts your strategy and military skills to the test. Raid other players for resources, place bounties on enemies, and unleash nuclear weapons for maximum impact. Global wars involve thousands of real players from all over the world in epic, world-shaking conflicts—not just brute force, but clever tactics and smart alliances."
        imageSrc="/images/war.jpg"
        imageAlt="Epic War Game"
        reverse
        bullets={[
          "Real-time combat with thousands of simultaneous players",
          "Naval, air, ground, and nuclear warfare mechanics",
          "Raid enemies, set bounties, and deploy weapons of mass destruction",
          "World wars that reshape the entire political landscape",
        ]}
      />

      <StatsBand />
      <ResourcesSection />

      <SectionBlock
        id="history"
        tag="Legacy"
        title="10+ Years of Rich History"
        description="Since launching on August 5, 2014, Politics and War has built a rich history filled with treaties, wars, alliances, and memorable events. The game's extensive history is documented across thousands of wiki pages, capturing the evolution of the player-driven world. Every decision you make becomes part of this larger, ongoing story."
        imageSrc="/images/history.jpg"
        imageAlt="Rich History"
        bullets={[
          "Launched August 5, 2014 — over a decade of history",
          "Thousands of wiki pages chronicling past events",
          "Historic wars, legendary alliances, and epic treaties",
          "A living world constantly being shaped by its players",
        ]}
      />

      <CommunitySection />
      <FounderSection />
      <AppDownload />
      <CTABanner />
      <Footer />
    </div>
  );
}
